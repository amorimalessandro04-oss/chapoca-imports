import express from 'express';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const app=express();const __dirname=path.dirname(fileURLToPath(import.meta.url));const port=Number(process.env.PORT||3000);
app.disable('x-powered-by');
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'chapoca-imports-web',backend:'supabase'}));
app.use(express.static(__dirname,{extensions:['html']}));
app.use((_req,res)=>res.sendFile(path.join(__dirname,'index.html')));
app.listen(port,()=>console.log(`Chapoca Imports em http://localhost:${port}`));
