# Chapoca Imports — versão pronta para teste

## Já configurado
- Loja pública responsiva.
- PWA instalável.
- Logo e ícones Chapoca Imports.
- Catálogo compartilhado no Supabase.
- Cadastro, edição, ocultação e entrada de estoque.
- Vendas e baixa automática de estoque.
- Financeiro.
- Login por Supabase Auth.
- Primeiro usuário criado vira administrador.
- Ctrl + G no PC e botão 🔐 Gestão no celular.
- Cadastro por câmera/galeria.
- IA visual preparada via Supabase Edge Function.
- Sem sugestão automática de preço.
- Fotos no Supabase Storage.

## Projeto Supabase
URL: https://hyfywucrzoywuhvgckyc.supabase.co

O frontend usa apenas a publishable key, que é própria para uso no navegador. Segredos de servidor não ficam no código.

## IA
A Edge Function `analyze-product` já foi publicada no projeto Supabase. Para a análise visual funcionar, é necessário cadastrar a `OPENAI_API_KEY` como segredo da função no Supabase. O modelo padrão está em `gpt-5.6-luna`.

## Publicação
Este diretório já contém `render.yaml`. No Render, conecte este diretório/repositório e o serviço será iniciado com `npm install` e `npm start`.

Não é necessário comprar domínio para testar. Depois o domínio pode ser conectado ao serviço.
