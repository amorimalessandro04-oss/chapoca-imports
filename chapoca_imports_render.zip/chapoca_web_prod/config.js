window.CHAPOCA_CONFIG={
  SUPABASE_URL:'https://hyfywucrzoywuhvgckyc.supabase.co',
  SUPABASE_KEY:'sb_publishable_TFzqmJGi9K842sDBSLwI0A_tYCAZu6A',
  AI_FUNCTION:'analyze-product',
  STORE_NAME:'Chapoca Imports'
};
