import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 3000);
const mime = {
  '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8',
  '.json':'application/json; charset=utf-8', '.webmanifest':'application/manifest+json; charset=utf-8',
  '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.webp':'image/webp', '.svg':'image/svg+xml',
  '.ico':'image/x-icon', '.txt':'text/plain; charset=utf-8'
};
function safePath(urlPath){
  let p;
  try { p = decodeURIComponent(urlPath.split('?')[0]); } catch { return null; }
  p = p.replace(/^\/+/, '/');
  const rel = p === '/' ? 'index.html' : p.slice(1);
  const full = path.resolve(__dirname, rel);
  if (full !== __dirname && !full.startsWith(__dirname + path.sep)) return null;
  return full;
}
const server = http.createServer((req,res)=>{
  if (req.url?.split('?')[0] === '/api/health') {
    res.writeHead(200, {'content-type':'application/json; charset=utf-8'});
    return res.end(JSON.stringify({ok:true,service:'chapoca-imports-web',backend:'supabase'}));
  }
  let file = safePath(req.url || '/');
  if (!file || !fs.existsSync(file) || !fs.statSync(file).isFile()) file = path.join(__dirname,'index.html');
  const ext = path.extname(file).toLowerCase();
  res.writeHead(200, {'content-type': mime[ext] || 'application/octet-stream', 'cache-control': ext==='.html'?'no-cache':'public, max-age=3600'});
  fs.createReadStream(file).pipe(res);
});
server.listen(port,'0.0.0.0',()=>console.log(`Chapoca Imports listening on ${port}`));
